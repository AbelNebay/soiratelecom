<?php

echo "Hello world - Soira Telecom Service";


?>